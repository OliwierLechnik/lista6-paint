package org.example.paint;

import java.io.*;
import java.util.ArrayList;

public class Shapes implements Serializable {
    private static Shapes instance;
    private ArrayList<PolygonShape> shapes;


    private Shapes(){
        this.shapes = new ArrayList<PolygonShape>();
    }

    public static Shapes getInstance(){
        if(instance == null){
            instance = new Shapes();
        }
        return instance;
    }

    public void add(PolygonShape shape){
        this.shapes.add(shape);
    }

    public void save(File file) throws IOException {
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
        objectOutputStream.writeObject(instance);
    }

    public void load(File file) throws IOException {
        FileInputStream fileInputStream = new FileInputStream(file);
        ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
        try{
            instance = (Shapes) objectInputStream.readObject();

        }catch (Exception e){
            System.out.println("Corrupted file");
            instance = new Shapes();
        }

    }

    public int size(){
        return this.shapes.size();
    }

    public PolygonShape get(int idx){

        try {
            return this.shapes.get(idx);
        }catch (Exception e){
            System.out.println(e.getMessage() + " " + idx + " / " + size());
            return null;
        }
    }

    public void set(int idx, PolygonShape shape){

        try {
            this.shapes.set(idx, shape);
        }catch (Exception e){
            System.out.println(e.getMessage() + " " + idx + " / " + size());
        }
    }

}
