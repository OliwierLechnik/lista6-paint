package org.example.paint;

import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.ColorPicker;
import javafx.scene.input.MouseButton;
import javafx.scene.input.ScrollEvent;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.util.Pair;

import java.io.File;
import java.io.PrintStream;


public class HelloController {

    private int focused = -1;
    private double xBegin;
    private double yBegin;

    private Type action = Type.NONE;

    private Color colour = Color.BLACK;

    @FXML
    public Canvas surface;

    @FXML
    public ColorPicker colourfx;

    public void save(){
        FileChooser fileChooser = new FileChooser();
        File file = fileChooser.showSaveDialog(surface.getScene().getWindow());
        try {
            Shapes.getInstance().save(file);
        }catch (Exception e){
            System.out.println("Something went wrong QwQ " + e.getMessage());
//            System.exit(0);
        }
    }
    public void load(){
        FileChooser fileChooser = new FileChooser();
        File file = fileChooser.showOpenDialog(surface.getScene().getWindow());
        try {
            Shapes.getInstance().load(file);
        }catch (Exception e){
            System.out.println("Something went wrong QwQ " + e.getMessage());
//            System.exit(0);
        }
    }
    public void info(){

    }


    public void setTriangle(){
        action = Type.TRIANGLE;
        focused = -1;
    }
    public void setRectangle(){
        action = Type.RECTANGLE;
        focused = -1;
    }
    public void setOval(){
        action = Type.OVAL;
        focused = -1;
    }
    public void setEdit(){
        action = Type.NONE;
        focused = -1;
    }
    public void changeColour(){
        colour = colourfx.getValue();
        if(focused != -1){
            Shapes.getInstance().get(focused).setColour(colour);
        }
    }

    public void onDragBegin(javafx.scene.input.MouseEvent event){
        xBegin = event.getX();
        yBegin = event.getY();
        System.out.println(":3");
        if(action == Type.NONE){
            for(int i = Shapes.getInstance().size()-1; i>=0; i--){

                System.out.println(i);
                System.out.println(Shapes.getInstance().size());
                System.out.println(" ");
                if(Shapes.getInstance().get(i).contains(event.getX(), event.getY())){
                    if(focused != -1){
                        Shapes.getInstance().get(focused).unFocus();
                    }
                    Shapes.getInstance().get(i).focus();
//                    colour = SharedData.getInstance().get(focused).getColour();
                    focused = i;
                    return;
                }
            }
            if(focused != -1){
                Shapes.getInstance().get(focused).unFocus();
                focused = -1;
            }
        } else if (action == Type.RECTANGLE) {
            Shapes.getInstance().add(PolygonShape.Rectangle(new Pair<Double,Double>(xBegin,yBegin), new Pair<Double,Double>(0.0,0.0), colour));
            focused = Shapes.getInstance().size()-1;
        }else if (action == Type.TRIANGLE) {
            Shapes.getInstance().add(PolygonShape.Triangle(new Pair<Double,Double>(xBegin,yBegin), new Pair<Double,Double>(0.0,0.0), colour));
            focused = Shapes.getInstance().size()-1;
        }else if (action == Type.OVAL) {
            Shapes.getInstance().add(PolygonShape.Oval(new Pair<Double,Double>(xBegin,yBegin), new Pair<Double,Double>(0.0,0.0), colour));
            focused = Shapes.getInstance().size()-1;
        }
    }



    public void onDrag(javafx.scene.input.MouseEvent event){
        if(focused != -1){
            if(event.getButton().equals(MouseButton.PRIMARY) && action == Type.NONE){
                Shapes.getInstance().get(focused).move(event.getX()-xBegin, event.getY()-yBegin);
                xBegin = event.getX();
                yBegin = event.getY();
            }
            if(event.getButton().equals(MouseButton.SECONDARY) && action == Type.NONE){
                Shapes.getInstance().get(focused).rotate(xBegin, yBegin, event.getX(), event.getY());
                xBegin = event.getX();
                yBegin = event.getY();
            }
            if(action == Type.RECTANGLE){
                Shapes.getInstance().set(focused,PolygonShape.Rectangle(new Pair<Double,Double>(xBegin,yBegin), new Pair<Double,Double>(event.getX()-xBegin,event.getY()-yBegin), colour));
            }
            if(action == Type.TRIANGLE){
                Shapes.getInstance().set(focused,PolygonShape.Triangle(new Pair<Double,Double>(xBegin,yBegin), new Pair<Double,Double>(event.getX()-xBegin,event.getY()-yBegin), colour));
            }
            if(action == Type.OVAL){

                Shapes.getInstance().set(focused,PolygonShape.Oval(new Pair<Double,Double>(xBegin,yBegin), new Pair<Double,Double>(event.getX()-xBegin,event.getY()-yBegin), colour));
            }
        }
    }

    public void onDragEnd(javafx.scene.input.MouseEvent event){

        action = Type.NONE;

        System.out.println(">~<");
    }


    public void onScroll(ScrollEvent event){
        System.out.println("0w0");
        if(focused != -1){
            if(event.getDeltaY() > 0){
                Shapes.getInstance().get(focused).upscale();
            }else if(event.getDeltaY() < 0){
                Shapes.getInstance().get(focused).downscale();
            }
        }
    }
}