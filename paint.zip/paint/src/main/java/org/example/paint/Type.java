package org.example.paint;

public enum Type {
    NONE,
    TRIANGLE,
    RECTANGLE,
    OVAL
}
