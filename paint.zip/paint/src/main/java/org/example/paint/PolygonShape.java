package org.example.paint;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.util.Pair;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PolygonShape implements Serializable {

    private static final long serialVersionUID = 2L;
    private static final double upscaleFactor = 1.1;
    private static final double downscaleFactor = 0.909;
    private boolean focused;

    private double[] x;
    private double[] y;
    private double[] ogx;
    private double[] ogy;
    private int count;
    private double r,g,b;
    private double centerx;
    private double centery;

    private Type type;



    private PolygonShape(List<Double> x, List<Double> y, Color colour){

        if(x.size() == 3){
            this.type = Type.TRIANGLE;
        }else if(x.size() == 4){
            this.type = Type.RECTANGLE;
        }else{
            this.type = Type.OVAL;
        }

        this.x = x.stream().mapToDouble(d -> d).toArray();
        this.y = y.stream().mapToDouble(d -> d).toArray();
        this.ogx = x.stream().mapToDouble(d -> d).toArray();
        this.ogy = y.stream().mapToDouble(d -> d).toArray();
        this.count = y.size();
        this.r = colour.getRed();
        this.g = colour.getGreen();
        this.b = colour.getBlue();
        this.focused = false;

        this.updateCenter();

    }

    private void updateCenter(){

        this.centerx = 0;
        this.centery = 0;

        for(int i = 0; i < count; i++){
            this.centerx += this.x[i];
            this.centery += this.y[i];
        }

        this.centerx /= count;
        this.centery /= count;
    }

    public static PolygonShape Rectangle(Pair<Double,Double> origin, Pair<Double,Double> size, Color colour){

        ArrayList<Double> x = new ArrayList<Double>();
        ArrayList<Double> y = new ArrayList<Double>();

        x.add(origin.getKey());
        y.add(origin.getValue());

        x.add(origin.getKey()+size.getKey());
        y.add(origin.getValue());

        x.add(origin.getKey()+size.getKey());
        y.add(origin.getValue()+size.getValue());

        x.add(origin.getKey());
        y.add(origin.getValue()+size.getValue());

        return new PolygonShape(x,y, colour);
    }
    public static PolygonShape Triangle(Pair<Double,Double> origin, Pair<Double,Double> size, Color colour){

        ArrayList<Double> x = new ArrayList<Double>();
        ArrayList<Double> y = new ArrayList<Double>();

        x.add(origin.getKey() + size.getKey()/2);
        y.add(origin.getValue());

        x.add(origin.getKey()+size.getKey());
        y.add(origin.getValue()+ size.getValue());

        x.add(origin.getKey());
        y.add(origin.getValue()+size.getValue());


        return new PolygonShape(x,y, colour);
    }

    public static PolygonShape Oval(Pair<Double,Double> origin, Pair<Double,Double> size, Color colour){

        ArrayList<Double> x = new ArrayList<Double>();
        ArrayList<Double> y = new ArrayList<Double>();

        for(int i = 0; i < 90; i++){
            x.add(size.getKey()*Math.cos(6.283*i/90.0)/2.0 + origin.getKey() + size.getKey()/2.0);
            y.add(size.getValue()*Math.sin(6.283*i/90.0)/2.0 + origin.getValue() + size.getValue()/2.0);
        }

        return new PolygonShape(x,y, colour);
    }


    public void focus(){
        this.focused = true;
    }

    public void unFocus(){
        this.focused = false;
    }


    public void draw(GraphicsContext surface){

        Color c = (Color) surface.getFill();

        surface.setFill(Color.color(r,g,b));
        surface.fillPolygon(this.x, this.y, this.count);

//        if(focused){
////            surface.setFill(focusedColour);
//            surface.strokePolyline(this.x,this.y,this.count);
//            surface.setFill(this.colour);
//        }

        surface.setFill(c);

    }



    public void rotate(double ox, double oy, double x, double y){


        double angle = Math.atan2(centerx - x,centery - y);

        double oangle = Math.atan2(centerx - ox, centery - oy);

        double dangle = oangle - angle;


        for(int i = 0; i<count; i++){
            this.x[i] = (this.ogx[i]-centerx)*Math.cos(dangle)-(this.ogy[i]-centery)*Math.sin(dangle) + centerx;
            this.y[i] = (this.ogy[i]-centery)*Math.cos(dangle)+(this.ogx[i]-centerx)*Math.sin(dangle) + centery;
        }

        for(int i = 0; i<count; i++){
            this.ogx[i] = this.x[i];
            this.ogy[i] = this.y[i];
        }



    }

    public void move(double dx, double dy){
        for(int i = 0; i < count; i++){
            this.x[i]+=dx;
            this.y[i]+=dy;
        }

        for(int i = 0; i<count; i++){
            this.ogx[i] = this.x[i];
            this.ogy[i] = this.y[i];
        }

        this.updateCenter();
    }

    private static boolean intersectPositive(double ax, double ay, double bx, double by){
        if(ay*by > 0){
            return false;
        }

        if(ay*by == 0){
            return true;
        }

        if(ax==bx){
            return (ax >= 0);
        }

        if(ay==by){
            return ay == 0 && (ax >= 0 || bx >= 0) && !(ax >= 0 && bx >= 0);
        }

        return 0 < bx - by*(ax-bx)/(ay-by);
    }

    public boolean contains(double x, double y){

        int sum = 0;

        for(int i = 0; i < count; i++){
            if(intersectPositive(
                    this.x[i]-x,
                    this.y[i]-y,
                    this.x[(i+1)%count]-x,
                    this.y[(i+1)%count]-y
                )){
                sum+=1;
            }
        }

        return sum%2==1;
    }

    private void scale(double factor){
        for(int i = 0; i<count; i++){
            this.x[i]*=factor;
            this.ogx[i]*=factor;
            this.y[i]*=factor;
            this.ogy[i]*=factor;
        }

        double newcenterx = 0;
        double newcentery = 0;

        for(int i = 0; i < count; i++){
            newcenterx += this.x[i];
            newcentery += this.y[i];
        }

        newcenterx /= count;
        newcentery /= count;

        for(int i = 0; i<count; i++){
            this.x[i]+= centerx - newcenterx;
            this.ogx[i]+= centerx - newcenterx;
            this.y[i]+= centery - newcentery;
            this.ogy[i]+= centery - newcentery;
        }
    }

    public Color getColour() {
        return Color.color(r,g,b);
    }

    public void setColour(Color colour){
        this.r = colour.getRed();
        this.g = colour.getGreen();
        this.b = colour.getBlue();
    }

    public void upscale(){

        this.scale(this.upscaleFactor);

    }
    public void downscale(){
        this.scale(this.downscaleFactor);
    }

}
